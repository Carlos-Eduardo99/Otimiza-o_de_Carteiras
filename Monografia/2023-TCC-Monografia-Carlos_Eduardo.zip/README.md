# iftex2020
Classe LaTeX para Trabalhos Acadêmicos do IFMG modelo 2020
